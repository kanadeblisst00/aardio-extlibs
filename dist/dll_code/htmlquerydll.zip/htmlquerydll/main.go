package main

/*
#include <stdlib.h>
#include <string.h>
*/
import "C"
import (
	"strings"
	"sync"
	"unsafe"

	"github.com/antchfx/htmlquery"
	"golang.org/x/net/html"
)

var (
	nodeMutex sync.Mutex
	nodeMap       = make(map[int]*html.Node)
	nodeIndex int = 1
)

//export ReleaseNode
func ReleaseNode(sIndex int) {
	nodeMutex.Lock()
	defer nodeMutex.Unlock()
	delete(nodeMap, sIndex)
}

//export ExistsAttr
func ExistsAttr(nIndex int, cStrName *C.char) bool {
	var name = C.GoString(cStrName)
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	var exist = htmlquery.ExistsAttr(topNode, name)
	return exist
}

//export Find_Each
func Find_Each(nIndex int, cStrExpr *C.char, funcCallback uintptr) bool {
	var expr = C.GoString(cStrExpr)
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	nodeList := htmlquery.Find(topNode, expr)
	for i, node := range nodeList {
		nodeMutex.Lock()
		index := nodeIndex
		nodeIndex++
		nodeMap[index] = node
		nodeMutex.Unlock()
		CallPtr(funcCallback, uintptr(i), uintptr(index))
	}
	return true
}

//export FindOne
func FindOne(nIndex int, cStrExpr *C.char) int {
	var expr = C.GoString(cStrExpr)
	nodeMutex.Lock()
	defer nodeMutex.Unlock()
	topNode, e := nodeMap[nIndex]
	if !e {
		return 0
	}
	newNode := htmlquery.FindOne(topNode, expr)
	if newNode == nil {
		return 0
	}
	index := nodeIndex
	nodeIndex++
	nodeMap[index] = newNode
	return index
}

//export InnerText
func InnerText(nIndex int, result *C.char) bool {
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	html := htmlquery.InnerText(topNode)
	v := C.CString(html)
	defer C.free(unsafe.Pointer(v))
	C.strcpy(result, v)
	return true
}

//export LoadDoc
func LoadDoc(cStrHtmlPath *C.char) int {
	var path = C.GoString(cStrHtmlPath)
	topNode, err := htmlquery.LoadDoc(path)
	if err != nil {
		return 0
	}
	nodeMutex.Lock()
	defer nodeMutex.Unlock()
	index := nodeIndex
	nodeIndex++
	nodeMap[index] = topNode
	return index
}

//export OutputHTML
func OutputHTML(nIndex int, self bool, result *C.char) bool {
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	html := htmlquery.OutputHTML(topNode, self)
	v := C.CString(html)
	defer C.free(unsafe.Pointer(v))
	C.strcpy(result, v)
	return true
}

//export Parse
func Parse(cHtml *C.char) int {
	var html = C.GoString(cHtml)
	topNode, err := htmlquery.Parse(strings.NewReader(html))
	if err != nil {
		return 0
	}
	nodeMutex.Lock()
	defer nodeMutex.Unlock()
	index := nodeIndex
	nodeIndex++
	nodeMap[index] = topNode
	return index
}

//export Query
func Query(nIndex int, cStrExpr *C.char) int {
	var expr = C.GoString(cStrExpr)
	nodeMutex.Lock()
	defer nodeMutex.Unlock()
	topNode, e := nodeMap[nIndex]
	if !e {
		return 0
	}
	newNode, err := htmlquery.Query(topNode, expr)
	if err != nil {
		return 0
	}
	if newNode == nil {
		return 0
	}
	index := nodeIndex
	nodeIndex++
	nodeMap[index] = newNode
	return index
}

//export QueryAll_Each
func QueryAll_Each(nIndex int, cStrExpr *C.char, funcCallback uintptr) bool {
	var expr = C.GoString(cStrExpr)
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	nodeList, err := htmlquery.QueryAll(topNode, expr)
	if err != nil {
		return false
	}
	for i, node := range nodeList {
		nodeMutex.Lock()
		index := nodeIndex
		nodeIndex++
		nodeMap[index] = node
		nodeMutex.Unlock()
		CallPtr(funcCallback, uintptr(i), uintptr(index))
	}
	return true
}

//export SelectAttr
func SelectAttr(nIndex int, cStrName *C.char, result *C.char) bool {
	var name = C.GoString(cStrName)
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	attrValue := htmlquery.SelectAttr(topNode, name)
	v := C.CString(attrValue)
	defer C.free(unsafe.Pointer(v))
	C.strcpy(result, v)
	return true
}

// 初始化函数，可以重复写多个
func init() {}

// 必须写个空的入口函数，实际不会执行
func main() {

}
