package main

/*
#include <stdlib.h>
#include <string.h>
*/
import "C"
import (
	"strings"
	"sync"
	"unsafe"

	"github.com/antchfx/xmlquery"
)

var (
	nodeMutex sync.Mutex
	nodeMap       = make(map[int]*xmlquery.Node)
	nodeIndex int = 1
)

//export ReleaseNode
func ReleaseNode(sIndex int) {
	nodeMutex.Lock()
	defer nodeMutex.Unlock()
	delete(nodeMap, sIndex)
}

//export AddAttr
func AddAttr(nIndex int, cStrKey *C.char, cStrValue *C.char) bool {
	var key = C.GoString(cStrKey)
	var val = C.GoString(cStrValue)
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	xmlquery.AddAttr(topNode, key, val)
	return true
}

//export AddChild
func AddChild(nIndex int, nIndex2 int) bool {
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	if !e {
		return false
	}
	topNode1, e := nodeMap[nIndex2]
	if !e {
		return false
	}
	nodeMutex.Unlock()
	xmlquery.AddChild(topNode, topNode1)
	return true
}

//export AddSibling
func AddSibling(nIndex int, nIndex2 int) bool {
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	if !e {
		return false
	}
	topNode1, e := nodeMap[nIndex2]
	if !e {
		return false
	}
	nodeMutex.Unlock()
	xmlquery.AddSibling(topNode, topNode1)
	return true
}

//export RemoveFromTree
func RemoveFromTree(nIndex int) bool {
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	if !e {
		return false
	}
	nodeMutex.Unlock()
	xmlquery.RemoveFromTree(topNode)
	return true
}

//export Find_Each
func Find_Each(nIndex int, cStrExpr *C.char, funcCallback uintptr) bool {
	var expr = C.GoString(cStrExpr)
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	nodeList := xmlquery.Find(topNode, expr)
	for i, node := range nodeList {
		nodeMutex.Lock()
		index := nodeIndex
		nodeIndex++
		nodeMap[index] = node
		nodeMutex.Unlock()
		CallPtr(funcCallback, uintptr(i), uintptr(index))
	}
	return true
}

//export FindOne
func FindOne(nIndex int, cStrExpr *C.char) int {
	var expr = C.GoString(cStrExpr)
	nodeMutex.Lock()
	defer nodeMutex.Unlock()
	topNode, e := nodeMap[nIndex]
	if !e {
		return 0
	}
	newNode := xmlquery.FindOne(topNode, expr)
	if newNode == nil {
		return 0
	}
	index := nodeIndex
	nodeIndex++
	nodeMap[index] = newNode
	return index
}

//export Parse
func Parse(cHtml *C.char) int {
	var html = C.GoString(cHtml)
	topNode, err := xmlquery.Parse(strings.NewReader(html))
	if err != nil {
		return 0
	}
	nodeMutex.Lock()
	defer nodeMutex.Unlock()
	index := nodeIndex
	nodeIndex++
	nodeMap[index] = topNode
	return index
}

//export Query
func Query(nIndex int, cStrExpr *C.char) int {
	var expr = C.GoString(cStrExpr)
	nodeMutex.Lock()
	defer nodeMutex.Unlock()
	topNode, e := nodeMap[nIndex]
	if !e {
		return 0
	}
	newNode, err := xmlquery.Query(topNode, expr)
	if err != nil {
		return 0
	}
	if newNode == nil {
		return 0
	}
	index := nodeIndex
	nodeIndex++
	nodeMap[index] = newNode
	return index
}

//export QueryAll_Each
func QueryAll_Each(nIndex int, cStrExpr *C.char, funcCallback uintptr) bool {
	var expr = C.GoString(cStrExpr)
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	nodeList, err := xmlquery.QueryAll(topNode, expr)
	if err != nil {
		return false
	}
	for i, node := range nodeList {
		nodeMutex.Lock()
		index := nodeIndex
		nodeIndex++
		nodeMap[index] = node
		nodeMutex.Unlock()
		CallPtr(funcCallback, uintptr(i), uintptr(index))
	}
	return true
}

//export InnerText
func InnerText(nIndex int, result *C.char) bool {
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	html := topNode.InnerText()
	v := C.CString(html)
	defer C.free(unsafe.Pointer(v))
	C.strcpy(result, v)
	return true
}

//export OutputXML
func OutputXML(nIndex int, self bool, result *C.char) bool {
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	html := topNode.OutputXML(self)
	v := C.CString(html)
	defer C.free(unsafe.Pointer(v))
	C.strcpy(result, v)
	return true
}

//export RemoveAttr
func RemoveAttr(nIndex int, cStrKey *C.char) bool {
	var key = C.GoString(cStrKey)
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	topNode.RemoveAttr(key)
	return true
}

//export SelectAttr
func SelectAttr(nIndex int, cStrKey *C.char, result *C.char) bool {
	var key = C.GoString(cStrKey)
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	html := topNode.SelectAttr(key)
	v := C.CString(html)
	defer C.free(unsafe.Pointer(v))
	C.strcpy(result, v)
	return true
}

//export SelectElement
func SelectElement(nIndex int, cStrName *C.char) int {
	var name = C.GoString(cStrName)
	nodeMutex.Lock()
	defer nodeMutex.Unlock()
	topNode, e := nodeMap[nIndex]
	if !e {
		return 0
	}
	newNode := topNode.SelectElement(name)
	if newNode == nil {
		return 0
	}
	index := nodeIndex
	nodeIndex++
	nodeMap[index] = newNode
	return index
}

//export SelectElements
func SelectElements(nIndex int, cStrName *C.char, funcCallback uintptr) bool {
	var name = C.GoString(cStrName)
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	nodeList := topNode.SelectElements(name)
	for i, node := range nodeList {
		nodeMutex.Lock()
		index := nodeIndex
		nodeIndex++
		nodeMap[index] = node
		nodeMutex.Unlock()
		CallPtr(funcCallback, uintptr(i), uintptr(index))
	}
	return true
}

//export SetAttr
func SetAttr(nIndex int, cStrKey *C.char, cStrValue *C.char) bool {
	var key = C.GoString(cStrKey)
	var val = C.GoString(cStrValue)
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	topNode.SetAttr(key, val)
	return true
}

// 初始化函数，可以重复写多个
func init() {}

// 必须写个空的入口函数，实际不会执行
func main() {

}
