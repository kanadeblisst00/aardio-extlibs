package main

/*
#include <stdlib.h>
#include <string.h>
*/
import "C"
import (
	"strings"
	"sync"
	"unsafe"

	"github.com/PuerkitoBio/goquery"
)

var (
	seleMutex sync.Mutex
	seleMap       = make(map[int]*goquery.Selection)
	seleIndex int = 200000
)

var (
	matcherMutex sync.Mutex
	matcherMap       = make(map[int]goquery.Matcher)
	matcherIndex int = 300000
)

//export NewDocumentFromReader
func NewDocumentFromReader(cHtml *C.char) int {
	var html = C.GoString(cHtml)
	doc, err := goquery.NewDocumentFromReader(strings.NewReader(html))
	if err != nil {
		return 0
	}
	seleMutex.Lock()
	defer seleMutex.Unlock()
	sIndex := seleIndex
	seleIndex++
	seleMap[sIndex] = doc.Selection
	return sIndex
}

//export ReleaseSelection
func ReleaseSelection(sIndex int) {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	delete(seleMap, sIndex)
}

//export ReleaseMatcher
func ReleaseMatcher(mIndex int) {
	matcherMutex.Lock()
	defer matcherMutex.Unlock()
	delete(matcherMap, mIndex)
}

//export NodeName
func NodeName(sIndex int, result *C.char) {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return
	}
	name := goquery.NodeName(s)
	cName := C.CString(name)
	defer C.free(unsafe.Pointer(cName))
	C.strcpy(result, cName)
}

//export OuterHtml
func OuterHtml(sIndex int, result *C.char) bool {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return false
	}
	html, err := goquery.OuterHtml(s)
	if err != nil {
		errCstr := C.CString(err.Error())
		C.strcpy(result, errCstr)
		C.free(unsafe.Pointer(errCstr))
		return false
	}
	htmlCstr := C.CString(html)
	defer C.free(unsafe.Pointer(htmlCstr))
	C.strcpy(result, htmlCstr)
	return true
}

//export Single
func Single(cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	matcherMutex.Lock()
	defer matcherMutex.Unlock()
	matcher := goquery.Single(selector)
	newMIndex := matcherIndex
	matcherIndex++
	matcherMap[newMIndex] = matcher
	return newMIndex
}

//export SingleMatcher
func SingleMatcher(mIndex int) int {
	matcherMutex.Lock()
	defer matcherMutex.Unlock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	newMatcher := goquery.SingleMatcher(matcher)
	newMIndex := matcherIndex
	matcherIndex++
	matcherMap[newMIndex] = newMatcher
	return newMIndex
}

//export Selection_Add
func Selection_Add(sIndex int, cStrSelector *C.char) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	var selector = C.GoString(cStrSelector)
	newSelection := s.Add(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_AddBack
func Selection_AddBack(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if exists {
		return 0
	}
	newSelection := s.AddBack()
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_AddBackFiltered
func Selection_AddBackFiltered(sIndex int, cStrSelector *C.char) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	var selector = C.GoString(cStrSelector)
	newSelection := s.AddBackFiltered(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_AddBackMatcher
func Selection_AddBackMatcher(sIndex int, mIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	newSelection := s.AddBackMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_AddMatcher
func Selection_AddMatcher(sIndex int, mIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	newSelection := s.AddMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_AddSelection
func Selection_AddSelection(sIndex1 int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s1 := seleMap[sIndex1]
	s2 := seleMap[sIndex2]
	newSelection := s1.AddSelection(s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_After
func Selection_After(sIndex int, cStrSelector *C.char) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	var selector = C.GoString(cStrSelector)
	newSelection := s.After(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_AfterHtml
func Selection_AfterHtml(sIndex int, cStrHtml *C.char) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	var html = C.GoString(cStrHtml)
	newSelection := s.AfterHtml(html)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_AfterMatcher
func Selection_AfterMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.AfterMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_AfterSelection
func Selection_AfterSelection(sIndex1 int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s1 := seleMap[sIndex1]
	s2 := seleMap[sIndex2]
	newSelection := s1.AfterSelection(s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Append
func Selection_Append(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Append(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_AppendHtml
func Selection_AppendHtml(sIndex int, cStrHtml *C.char) int {
	var html = C.GoString(cStrHtml)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.AppendHtml(html)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_AppendMatcher
func Selection_AppendMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.AppendMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_AppendSelection
func Selection_AppendSelection(sIndex1 int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s1 := seleMap[sIndex1]
	s2 := seleMap[sIndex2]
	newSelection := s1.AppendSelection(s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Attr
func Selection_Attr(sIndex int, cStrAttrName *C.char, result *C.char) bool {
	var attrName = C.GoString(cStrAttrName)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return false
	}
	attrValue, exists := s.Attr(attrName)
	if exists == true {
		v := C.CString(attrValue)
		defer C.free(unsafe.Pointer(v))
		C.strcpy(result, v)
		return true
	}
	return false
}

//export Selection_AttrOr
func Selection_AttrOr(sIndex int, cStrAttrName *C.char, cStrDefaultValue *C.char, result *C.char) {
	var attrName = C.GoString(cStrAttrName)
	var defaultValue = C.GoString(cStrDefaultValue)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return
	}
	attrValue := s.AttrOr(attrName, defaultValue)
	v := C.CString(attrValue)
	defer C.free(unsafe.Pointer(v))
	C.strcpy(result, v)
}

//export Selection_Before
func Selection_Before(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Before(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_BeforeHtml
func Selection_BeforeHtml(sIndex int, cStrHtml *C.char) int {
	var html = C.GoString(cStrHtml)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.BeforeHtml(html)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_BeforeMatcher
func Selection_BeforeMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.BeforeMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_BeforeSelection
func Selection_BeforeSelection(sIndex1 int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s1 := seleMap[sIndex1]
	s2 := seleMap[sIndex2]
	newSelection := s1.BeforeSelection(s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Children
func Selection_Children(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Children()
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ChildrenFiltered
func Selection_ChildrenFiltered(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.ChildrenFiltered(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ChildrenMatcher
func Selection_ChildrenMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.ChildrenMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Clone
func Selection_Clone(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Clone()
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Closest
func Selection_Closest(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Closest(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ClosestMatcher
func Selection_ClosestMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.ClosestMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ClosestSelection
func Selection_ClosestSelection(sIndex1 int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s1 := seleMap[sIndex1]
	s2 := seleMap[sIndex2]
	newSelection := s1.ClosestSelection(s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Contents
func Selection_Contents(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Contents()
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ContentsFiltered
func Selection_ContentsFiltered(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.ContentsFiltered(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ContentsMatcher
func Selection_ContentsMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.ContentsMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Each
func Selection_Each(sIndex int, funcCallback uintptr) int {
	seleMutex.Lock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	seleMutex.Unlock()
	s.Each(func(i int, s *goquery.Selection) {
		seleMutex.Lock()
		newDIndex := seleIndex
		seleIndex++
		seleMap[newDIndex] = s
		seleMutex.Unlock()
		CallPtr(funcCallback, uintptr(i), uintptr(newDIndex))
	})
	return sIndex
}

//export Selection_EachWithBreak
func Selection_EachWithBreak(sIndex int, funcCallback uintptr) int {
	seleMutex.Lock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	seleMutex.Unlock()
	s.EachWithBreak(func(i int, s *goquery.Selection) bool {
		seleMutex.Lock()
		newDIndex := seleIndex
		seleIndex++
		seleMap[newDIndex] = s
		seleMutex.Unlock()
		var r, _, _ = CallPtr(funcCallback, uintptr(i), uintptr(newDIndex))
		return int(r) != 0
	})
	return sIndex
}

//export Selection_Empty
func Selection_Empty(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Empty()
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_End
func Selection_End(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.End()
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Eq
func Selection_Eq(sIndex int, index int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Eq(index)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Filter
func Selection_Filter(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Filter(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_FilterFunction
func Selection_FilterFunction(sIndex int, funcCallback uintptr) int {
	seleMutex.Lock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	seleMutex.Unlock()
	newSelection := s.FilterFunction(func(i int, s *goquery.Selection) bool {
		seleMutex.Lock()
		newDIndex := seleIndex
		seleIndex++
		seleMap[newDIndex] = s
		seleMutex.Unlock()
		var r, _, _ = CallPtr(funcCallback, uintptr(i), uintptr(newDIndex))
		return int(r) != 0
	})
	if newSelection == nil {
		return 0
	}
	seleMutex.Lock()
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	seleMutex.Unlock()
	return newDIndex
}

//export Selection_FilterMatcher
func Selection_FilterMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.FilterMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_FilterSelection
func Selection_FilterSelection(sIndex int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.FilterSelection(s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Find
func Selection_Find(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Find(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_FindMatcher
func Selection_FindMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.FindMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_FindSelection
func Selection_FindSelection(sIndex int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.FindSelection(s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_First
func Selection_First(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.First()
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Has
func Selection_Has(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Has(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_HasClass
func Selection_HasClass(sIndex int, cStrClass *C.char) bool {
	var class = C.GoString(cStrClass)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return false
	}
	return s.HasClass(class)
}

//export Selection_HasMatcher
func Selection_HasMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.HasMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_HasSelection
func Selection_HasSelection(sIndex int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.HasSelection(s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Html
func Selection_Html(sIndex int, result *C.char) bool {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return false
	}
	html, err := s.Html()
	if err != nil {
		v := C.CString(err.Error())
		defer C.free(unsafe.Pointer(v))
		C.strcpy(result, v)
		return true
	}
	v := C.CString(html)
	defer C.free(unsafe.Pointer(v))
	C.strcpy(result, v)
	return true
}

//export Selection_Index
func Selection_Index(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	i := s.Index()
	return i
}

//export Selection_IndexMatcher
func Selection_IndexMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	i := s.IndexMatcher(matcher)
	return i
}

//export Selection_IndexOfSelection
func Selection_IndexOfSelection(sIndex int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	i := s.IndexOfSelection(s2)
	return i
}

//export Selection_IndexSelector
func Selection_IndexSelector(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	i := s.IndexSelector(selector)
	return i
}

//export Selection_Is
func Selection_Is(sIndex int, cStrSelector *C.char) bool {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return false
	}
	i := s.Is(selector)
	return i
}

//export Selection_IsFunction
func Selection_IsFunction(sIndex int, funcCallback uintptr) bool {
	seleMutex.Lock()
	s, exists := seleMap[sIndex]
	if !exists {
		return false
	}
	seleMutex.Unlock()
	i := s.IsFunction(func(i int, s *goquery.Selection) bool {
		seleMutex.Lock()
		newDIndex := seleIndex
		seleIndex++
		seleMap[newDIndex] = s
		seleMutex.Unlock()
		var r, _, _ = CallPtr(funcCallback, uintptr(i), uintptr(newDIndex))
		return int(r) != 0
	})
	return i
}

//export Selection_IsMatcher
func Selection_IsMatcher(sIndex int, mIndex int) bool {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return false
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return false
	}
	i := s.IsMatcher(matcher)
	return i
}

//export Selection_IsSelection
func Selection_IsSelection(sIndex int, sIndex2 int) bool {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return false
	}
	s2 := seleMap[sIndex2]
	i := s.IsSelection(s2)
	return i
}

//export Selection_Last
func Selection_Last(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Last()
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Length
func Selection_Length(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	i := s.Length()
	return i
}

//export Selection_Next
func Selection_Next(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Next()
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_NextAll
func Selection_NextAll(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.NextAll()
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_NextAllFiltered
func Selection_NextAllFiltered(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.NextAllFiltered(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_NextAllMatcher
func Selection_NextAllMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.NextAllMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_NextFiltered
func Selection_NextFiltered(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.NextFiltered(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_NextFilteredUntil
func Selection_NextFilteredUntil(sIndex int, cStrFilterSelector *C.char, cStrUntilSelector *C.char) int {
	var filterSelector = C.GoString(cStrFilterSelector)
	var untilSelector = C.GoString(cStrUntilSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.NextFilteredUntil(filterSelector, untilSelector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_NextFilteredUntilMatcher
func Selection_NextFilteredUntilMatcher(sIndex int, mIndexFilter int, mIndexUntil int) int {
	matcherMutex.Lock()
	matcherFilter := matcherMap[mIndexFilter]
	matcherUntil := matcherMap[mIndexUntil]
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.NextFilteredUntilMatcher(matcherFilter, matcherUntil)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_NextFilteredUntilSelection
func Selection_NextFilteredUntilSelection(sIndex int, cStrFilterSelector *C.char, sIndex2 int) int {
	var filterSelector = C.GoString(cStrFilterSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.NextFilteredUntilSelection(filterSelector, s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_NextMatcher
func Selection_NextMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.NextMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_NextMatcherUntilSelection
func Selection_NextMatcherUntilSelection(sIndex int, mIndex int, sIndex2 int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.NextMatcherUntilSelection(matcher, s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_NextUntil
func Selection_NextUntil(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.NextUntil(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_NextUntilMatcher
func Selection_NextUntilMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.NextUntilMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_NextUntilSelection
func Selection_NextUntilSelection(sIndex int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.NextUntilSelection(s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Not
func Selection_Not(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Not(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_NotFunction
func Selection_NotFunction(sIndex int, funcCallback uintptr) int {
	seleMutex.Lock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	seleMutex.Unlock()
	newSelection := s.NotFunction(func(i int, s *goquery.Selection) bool {
		seleMutex.Lock()
		newDIndex := seleIndex
		seleIndex++
		seleMap[newDIndex] = s
		seleMutex.Unlock()
		var r, _, _ = CallPtr(funcCallback, uintptr(i), uintptr(newDIndex))
		return int(r) != 0
	})
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_NotMatcher
func Selection_NotMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.NotMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_NotSelection
func Selection_NotSelection(sIndex int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.NotSelection(s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Parent
func Selection_Parent(sIndex int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.NotSelection(s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ParentFiltered
func Selection_ParentFiltered(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.ParentFiltered(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ParentMatcher
func Selection_ParentMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.ParentMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Parents
func Selection_Parents(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Parents()
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ParentsFiltered
func Selection_ParentsFiltered(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.ParentsFiltered(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ParentsFilteredUntil
func Selection_ParentsFilteredUntil(sIndex int, cStrFilterSelector *C.char, cStrUntilSelector *C.char) int {
	var filterSelector = C.GoString(cStrFilterSelector)
	var untilSelector = C.GoString(cStrUntilSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.ParentsFilteredUntil(filterSelector, untilSelector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ParentsFilteredUntilMatcher
func Selection_ParentsFilteredUntilMatcher(sIndex int, mIndexFilter int, mIndexUntil int) int {
	matcherMutex.Lock()
	matcherFilter := matcherMap[mIndexFilter]
	matcherUntil := matcherMap[mIndexUntil]
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.ParentsFilteredUntilMatcher(matcherFilter, matcherUntil)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ParentsFilteredUntilSelection
func Selection_ParentsFilteredUntilSelection(sIndex int, cStrFilterSelector *C.char, sIndex2 int) int {
	var filterSelector = C.GoString(cStrFilterSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.ParentsFilteredUntilSelection(filterSelector, s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ParentsMatcher
func Selection_ParentsMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.ParentsMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ParentsMatcherUntilSelection
func Selection_ParentsMatcherUntilSelection(sIndex int, mIndex int, sIndex2 int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.ParentsMatcherUntilSelection(matcher, s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ParentsUntil
func Selection_ParentsUntil(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.ParentsUntil(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ParentsUntilMatcher
func Selection_ParentsUntilMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.ParentsUntilMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ParentsUntilSelection
func Selection_ParentsUntilSelection(sIndex int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.ParentsUntilSelection(s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Prepend
func Selection_Prepend(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Prepend(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_PrependHtml
func Selection_PrependHtml(sIndex int, cStrHtml *C.char) int {
	var html = C.GoString(cStrHtml)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.PrependHtml(html)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_PrependMatcher
func Selection_PrependMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.PrependMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_PrependSelection
func Selection_PrependSelection(sIndex int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.PrependSelection(s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Prev
func Selection_Prev(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Prev()
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_PrevAll
func Selection_PrevAll(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.PrevAll()
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_PrevAllFiltered
func Selection_PrevAllFiltered(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.PrevAllFiltered(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_PrevAllMatcher
func Selection_PrevAllMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.PrevAllMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_PrevFiltered
func Selection_PrevFiltered(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.PrevFiltered(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_PrevFilteredUntil
func Selection_PrevFilteredUntil(sIndex int, cStrFilterSelector *C.char, cStrUntilSelector *C.char) int {
	var filterSelector = C.GoString(cStrFilterSelector)
	var untilSelector = C.GoString(cStrUntilSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.PrevFilteredUntil(filterSelector, untilSelector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_PrevFilteredUntilMatcher
func Selection_PrevFilteredUntilMatcher(sIndex int, mIndexFilter int, mIndexUntil int) int {
	matcherMutex.Lock()
	matcherFilter := matcherMap[mIndexFilter]
	matcherUntil := matcherMap[mIndexUntil]
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.PrevFilteredUntilMatcher(matcherFilter, matcherUntil)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_PrevFilteredUntilSelection
func Selection_PrevFilteredUntilSelection(sIndex int, cStrFilterSelector *C.char, sIndex2 int) int {
	var filterSelector = C.GoString(cStrFilterSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.PrevFilteredUntilSelection(filterSelector, s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_PrevMatcher
func Selection_PrevMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.PrevMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_PrevMatcherUntilSelection
func Selection_PrevMatcherUntilSelection(sIndex int, mIndex int, sIndex2 int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.PrevMatcherUntilSelection(matcher, s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_PrevUntil
func Selection_PrevUntil(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.PrevUntil(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_PrevUntilMatcher
func Selection_PrevUntilMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.PrevUntilMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_PrevUntilSelection
func Selection_PrevUntilSelection(sIndex int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.PrevUntilSelection(s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Remove
func Selection_Remove(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Remove()
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_RemoveAttr
func Selection_RemoveAttr(sIndex int, cStrAttrName *C.char) int {
	var attrName = C.GoString(cStrAttrName)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.RemoveAttr(attrName)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_RemoveFiltered
func Selection_RemoveFiltered(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.RemoveFiltered(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_RemoveMatcher
func Selection_RemoveMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.RemoveMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ReplaceWith
func Selection_ReplaceWith(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.ReplaceWith(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ReplaceWithHtml
func Selection_ReplaceWithHtml(sIndex int, cStrHtml *C.char) int {
	var html = C.GoString(cStrHtml)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.ReplaceWithHtml(html)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ReplaceWithMatcher
func Selection_ReplaceWithMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.ReplaceWithMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_ReplaceWithSelection
func Selection_ReplaceWithSelection(sIndex int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.ReplaceWithSelection(s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_SetAttr
func Selection_SetAttr(sIndex int, cStrAttrName *C.char, cStrValue *C.char) int {
	var attrName = C.GoString(cStrAttrName)
	var value = C.GoString(cStrValue)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.SetAttr(attrName, value)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_SetHtml
func Selection_SetHtml(sIndex int, cStrHtml *C.char) int {
	var html = C.GoString(cStrHtml)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.SetHtml(html)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_SetText
func Selection_SetText(sIndex int, cStrText *C.char) int {
	var text = C.GoString(cStrText)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.SetText(text)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Siblings
func Selection_Siblings(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Siblings()
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_SiblingsFiltered
func Selection_SiblingsFiltered(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.SiblingsFiltered(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_SiblingsMatcher
func Selection_SiblingsMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.SiblingsMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Size
func Selection_Size(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	i := s.Size()
	return i
}

//export Selection_Slice
func Selection_Slice(sIndex int, start int, end int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Slice(start, end)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Text
func Selection_Text(sIndex int, result *C.char) {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return
	}
	text := s.Text()
	cName := C.CString(text)
	defer C.free(unsafe.Pointer(cName))
	C.strcpy(result, cName)
}

//export Selection_Union
func Selection_Union(sIndex int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.Union(s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Unwrap
func Selection_Unwrap(sIndex int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Unwrap()
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_Wrap
func Selection_Wrap(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.Wrap(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_WrapAll
func Selection_WrapAll(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.WrapAll(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_WrapAllHtml
func Selection_WrapAllHtml(sIndex int, cStrHtml *C.char) int {
	var html = C.GoString(cStrHtml)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.WrapAll(html)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_WrapAllMatcher
func Selection_WrapAllMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.WrapAllMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_WrapAllSelection
func Selection_WrapAllSelection(sIndex int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.WrapAllSelection(s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_WrapHtml
func Selection_WrapHtml(sIndex int, cStrHtml *C.char) int {
	var html = C.GoString(cStrHtml)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.WrapHtml(html)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_WrapInner
func Selection_WrapInner(sIndex int, cStrSelector *C.char) int {
	var selector = C.GoString(cStrSelector)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.WrapInner(selector)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_WrapInnerHtml
func Selection_WrapInnerHtml(sIndex int, cStrHtml *C.char) int {
	var html = C.GoString(cStrHtml)
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.WrapInnerHtml(html)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_WrapInnerMatcher
func Selection_WrapInnerMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.WrapInnerMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_WrapInnerSelection
func Selection_WrapInnerSelection(sIndex int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.WrapInnerSelection(s2)
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_WrapMatcher
func Selection_WrapMatcher(sIndex int, mIndex int) int {
	matcherMutex.Lock()
	matcher, mExists := matcherMap[mIndex]
	if !mExists {
		return 0
	}
	matcherMutex.Unlock()
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	newSelection := s.WrapMatcher(matcher)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

//export Selection_WrapSelection
func Selection_WrapSelection(sIndex int, sIndex2 int) int {
	seleMutex.Lock()
	defer seleMutex.Unlock()
	s, exists := seleMap[sIndex]
	if !exists {
		return 0
	}
	s2 := seleMap[sIndex2]
	newSelection := s.WrapSelection(s2)
	if newSelection == nil {
		return 0
	}
	newDIndex := seleIndex
	seleIndex++
	seleMap[newDIndex] = newSelection
	return newDIndex
}

// 初始化函数，可以重复写多个
func init() {}

// 必须写个空的入口函数，实际不会执行
func main() {

}
