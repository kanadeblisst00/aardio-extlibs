package main

/*
#include <stdlib.h>
#include <string.h>
*/
import "C"
import (
	"strings"
	"sync"
	"unsafe"

	"github.com/antchfx/jsonquery"
)

var (
	nodeMutex sync.Mutex
	nodeMap       = make(map[int]*jsonquery.Node)
	nodeIndex int = 1
)

//export ReleaseNode
func ReleaseNode(sIndex int) {
	nodeMutex.Lock()
	defer nodeMutex.Unlock()
	delete(nodeMap, sIndex)
}

//export Find_Each
func Find_Each(nIndex int, cStrExpr *C.char, funcCallback uintptr) bool {
	var expr = C.GoString(cStrExpr)
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	nodeList := jsonquery.Find(topNode, expr)
	for i, node := range nodeList {
		nodeMutex.Lock()
		index := nodeIndex
		nodeIndex++
		nodeMap[index] = node
		nodeMutex.Unlock()
		CallPtr(funcCallback, uintptr(i), uintptr(index))
	}
	return true
}

//export FindOne
func FindOne(nIndex int, cStrExpr *C.char) int {
	var expr = C.GoString(cStrExpr)
	nodeMutex.Lock()
	defer nodeMutex.Unlock()
	topNode, e := nodeMap[nIndex]
	if !e {
		return 0
	}
	newNode := jsonquery.FindOne(topNode, expr)
	if newNode == nil {
		return 0
	}
	index := nodeIndex
	nodeIndex++
	nodeMap[index] = newNode
	return index
}

//export Parse
func Parse(cHtml *C.char) int {
	var html = C.GoString(cHtml)
	topNode, err := jsonquery.Parse(strings.NewReader(html))
	if err != nil {
		return 0
	}
	nodeMutex.Lock()
	defer nodeMutex.Unlock()
	index := nodeIndex
	nodeIndex++
	nodeMap[index] = topNode
	return index
}

//export Query
func Query(nIndex int, cStrExpr *C.char) int {
	var expr = C.GoString(cStrExpr)
	nodeMutex.Lock()
	defer nodeMutex.Unlock()
	topNode, e := nodeMap[nIndex]
	if !e {
		return 0
	}
	newNode, err := jsonquery.Query(topNode, expr)
	if err != nil {
		return 0
	}
	index := nodeIndex
	nodeIndex++
	nodeMap[index] = newNode
	return index
}

//export QueryAll_Each
func QueryAll_Each(nIndex int, cStrExpr *C.char, funcCallback uintptr) bool {
	var expr = C.GoString(cStrExpr)
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	nodeList, err := jsonquery.QueryAll(topNode, expr)
	if err != nil {
		return false
	}
	for i, node := range nodeList {
		nodeMutex.Lock()
		index := nodeIndex
		nodeIndex++
		nodeMap[index] = node
		nodeMutex.Unlock()
		CallPtr(funcCallback, uintptr(i), uintptr(index))
	}
	return true
}

//export ChildNodes_Each
func ChildNodes_Each(nIndex int, funcCallback uintptr) bool {
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	nodeList := topNode.ChildNodes()
	for i, node := range nodeList {
		nodeMutex.Lock()
		index := nodeIndex
		nodeIndex++
		nodeMap[index] = node
		nodeMutex.Unlock()
		CallPtr(funcCallback, uintptr(i), uintptr(index))
	}
	return true
}

//export OutputXML
func OutputXML(nIndex int, result *C.char) bool {
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	html := topNode.OutputXML()
	v := C.CString(html)
	defer C.free(unsafe.Pointer(v))
	C.strcpy(result, v)
	return true
}

//export InnerText
func InnerText(nIndex int, result *C.char) bool {
	nodeMutex.Lock()
	topNode, e := nodeMap[nIndex]
	nodeMutex.Unlock()
	if !e {
		return false
	}
	text := topNode.InnerText()
	v := C.CString(text)
	defer C.free(unsafe.Pointer(v))
	C.strcpy(result, v)
	return true
}

//export SelectElement
func SelectElement(nIndex int, cStrName *C.char) int {
	var name = C.GoString(cStrName)
	nodeMutex.Lock()
	defer nodeMutex.Unlock()
	topNode, e := nodeMap[nIndex]
	if !e {
		return 0
	}
	newNode := topNode.SelectElement(name)
	if newNode == nil {
		return 0
	}
	index := nodeIndex
	nodeIndex++
	nodeMap[index] = newNode
	return index
}

// 初始化函数，可以重复写多个
func init() {}

// 必须写个空的入口函数，实际不会执行
func main() {

}
